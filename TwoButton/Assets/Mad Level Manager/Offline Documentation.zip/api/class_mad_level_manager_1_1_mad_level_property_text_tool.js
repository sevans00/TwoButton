var class_mad_level_manager_1_1_mad_level_property_text_tool =
[
    [ "font", "class_mad_level_manager_1_1_mad_level_property_text_tool.html#a9dff1308eb7bc1e34ce38743000b4983", null ],
    [ "icon", "class_mad_level_manager_1_1_mad_level_property_text_tool.html#a2210ca830d2eed190d02073fc9135ab5", null ],
    [ "name", "class_mad_level_manager_1_1_mad_level_property_text_tool.html#ae112fef55484b7dc68251386bb8148d6", null ]
];