var class___n_a_m_e_s_p_a_c_e___1_1_mad_font =
[
    [ "Glyph", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font_1_1_glyph.html", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font_1_1_glyph" ],
    [ "CreateStatus", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#a34601f5d8d044ecfb1e862bed3d0f389", [
      [ "None", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#a34601f5d8d044ecfb1e862bed3d0f389a6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Ok", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#a34601f5d8d044ecfb1e862bed3d0f389aa60852f204ed8028c1c58808b746d115", null ],
      [ "TooMuchGlypsDefined", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#a34601f5d8d044ecfb1e862bed3d0f389a36bf2f720247e722728ee1f76ce04b8f", null ],
      [ "TooMuchGlypsFound", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#a34601f5d8d044ecfb1e862bed3d0f389ab4b2a4a201a4aa45ab54fac02d03e371", null ]
    ] ],
    [ "InputType", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#ae5ebf6c91ba1321bc5b528c8b79cbe76", [
      [ "TextureAndGlyphList", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#ae5ebf6c91ba1321bc5b528c8b79cbe76a96a7ff0a418c6271168f8f7780d272bc", null ],
      [ "Bitmap", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#ae5ebf6c91ba1321bc5b528c8b79cbe76a86ee74baff479d85d18f2cda9f8a9518", null ]
    ] ],
    [ "GetHashCode", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#ab6b7191fea61351a222e4f7114b0777a", null ],
    [ "GlyphFor", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#a276ebcdb6369f352a1b4025af4994f6a", null ],
    [ "created", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#a97d25312ab36316a7bdbf1ebae89b615", null ],
    [ "createStatus", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#abe43457095748259c7472f86a4c0be9a", null ],
    [ "dimensions", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#adc2eb7fcf6165394009add14c8bb0d08", null ],
    [ "fillFactorTolerance", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#a9965f78db6233c3891611ae952fad7e0", null ],
    [ "fntFile", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#af7baec78b3ef9487ecf65152d309de50", null ],
    [ "forceWhite", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#ae160389a0046bd8bac0effcc41840630", null ],
    [ "glyphs", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#a4c3a19a59496045c847b58de4e2dd083", null ],
    [ "height", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#aef154a48889241ca5f1f06d77a5d6919", null ],
    [ "inputType", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#a349fe0266a928613921ccc3ad9262c03", null ],
    [ "linesCount", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#a01d8da4f3953d97c6e84de4f4117e4ca", null ],
    [ "material", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#a1857ab7626e66efbf5b9f8624ecd6f73", null ],
    [ "texture", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#a7ed071c1b7fc924584b8d488c002b8b3", null ],
    [ "data", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#ac031ede35200d36a58364f326fda2afe", null ],
    [ "dirty", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#a8fe29ed03bc3d5aaaa30a83f5fa688ee", null ],
    [ "initialized", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#a45f1703fffb908def67ff0add1094b55", null ],
    [ "textureAspect", "class___n_a_m_e_s_p_a_c_e___1_1_mad_font.html#a1ab23cf99fc94e81a41747b86b9eee5b", null ]
];