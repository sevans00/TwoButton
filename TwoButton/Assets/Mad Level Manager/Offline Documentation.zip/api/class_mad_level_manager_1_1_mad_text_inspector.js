var class_mad_level_manager_1_1_mad_text_inspector =
[
    [ "OnEnable", "class_mad_level_manager_1_1_mad_text_inspector.html#ab963e01dc0a9b0fe1b6645e59ef8343d", null ],
    [ "OnInspectorGUI", "class_mad_level_manager_1_1_mad_text_inspector.html#adaf9c91dc30b76854cca44d9a84d1b22", null ]
];