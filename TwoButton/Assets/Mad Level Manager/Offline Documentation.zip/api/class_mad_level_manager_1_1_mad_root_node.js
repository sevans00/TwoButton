var class_mad_level_manager_1_1_mad_root_node =
[
    [ "ResizeMode", "class_mad_level_manager_1_1_mad_root_node.html#a94e9779408f860f0f3a4a9a284d3b913", [
      [ "PixelPerfect", "class_mad_level_manager_1_1_mad_root_node.html#a94e9779408f860f0f3a4a9a284d3b913a1ac6cfc61658bee4cbd8851821d9288d", null ],
      [ "FixedSize", "class_mad_level_manager_1_1_mad_root_node.html#a94e9779408f860f0f3a4a9a284d3b913a8bc66ef376d634aaa714727085b9acfe", null ]
    ] ],
    [ "ScreenGlobal", "class_mad_level_manager_1_1_mad_root_node.html#afec639a412cc3b717e928fc0436bbd76", null ],
    [ "ScreenToLocal", "class_mad_level_manager_1_1_mad_root_node.html#a0d5e9fa2b05be8a5aa5e85a6cc3f3a54", null ],
    [ "manualHeight", "class_mad_level_manager_1_1_mad_root_node.html#a5667c1d15247f0a3433aaaaa2945fb96", null ],
    [ "maximumHeight", "class_mad_level_manager_1_1_mad_root_node.html#af6af8785f3ba1629faf8aef346ff3cd4", null ],
    [ "minimumHeight", "class_mad_level_manager_1_1_mad_root_node.html#a9b3da1dd96773390c2b83c0677845b2d", null ],
    [ "resizeMode", "class_mad_level_manager_1_1_mad_root_node.html#a9b4e113a49b6c587e2afc39180180647", null ],
    [ "pixelSize", "class_mad_level_manager_1_1_mad_root_node.html#a08b0fd6ba0e36173978359919b83d7d5", null ],
    [ "screenHeight", "class_mad_level_manager_1_1_mad_root_node.html#a71f0208f25a952722ec703e0097463c2", null ],
    [ "screenWidth", "class_mad_level_manager_1_1_mad_root_node.html#a9ca8f04e3d20f3522889ae4dd062ba58", null ]
];