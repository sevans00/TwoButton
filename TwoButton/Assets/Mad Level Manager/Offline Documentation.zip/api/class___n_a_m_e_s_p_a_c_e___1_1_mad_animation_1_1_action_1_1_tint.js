var class___n_a_m_e_s_p_a_c_e___1_1_mad_animation_1_1_action_1_1_tint =
[
    [ "color", "class___n_a_m_e_s_p_a_c_e___1_1_mad_animation_1_1_action_1_1_tint.html#aab1bdb29d1beccd1963f6710bc230a17", null ],
    [ "useBase", "class___n_a_m_e_s_p_a_c_e___1_1_mad_animation_1_1_action_1_1_tint.html#ac36813be113d29375d2b5dcdf626dc42", null ]
];