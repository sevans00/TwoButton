var class___n_a_m_e_s_p_a_c_e___1_1_mad_text_inspector =
[
    [ "OnEnable", "class___n_a_m_e_s_p_a_c_e___1_1_mad_text_inspector.html#a9957f2ab32905f34f7f7fd7f4eb743ed", null ],
    [ "OnInspectorGUI", "class___n_a_m_e_s_p_a_c_e___1_1_mad_text_inspector.html#ad021f985818b07ff5835f499b1862db1", null ]
];