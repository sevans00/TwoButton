var class_mad_level_manager_1_1_mad_level_property_sprite_tool =
[
    [ "icon", "class_mad_level_manager_1_1_mad_level_property_sprite_tool.html#a34c6b695618e7b65b4fe092200f6cd9b", null ],
    [ "name", "class_mad_level_manager_1_1_mad_level_property_sprite_tool.html#a249e66755c4cc860eb30aef196a4b777", null ],
    [ "texture", "class_mad_level_manager_1_1_mad_level_property_sprite_tool.html#aab7407d65c95a72f3c0ade6418172d76", null ]
];