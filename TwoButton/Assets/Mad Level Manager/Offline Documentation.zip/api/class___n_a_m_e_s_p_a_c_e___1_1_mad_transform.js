var class___n_a_m_e_s_p_a_c_e___1_1_mad_transform =
[
    [ "Predicate< T >", "class___n_a_m_e_s_p_a_c_e___1_1_mad_transform.html#a67c464c381d4e0056390fd488eefb1a2", null ]
];