var class_mad_level_manager_1_1_mad_level_property =
[
    [ "SpecialType", "class_mad_level_manager_1_1_mad_level_property.html#aada9032835fed60f84e59f64f8b6783d", [
      [ "Regular", "class_mad_level_manager_1_1_mad_level_property.html#aada9032835fed60f84e59f64f8b6783dad2203cb1237cb6460cbad94564e39345", null ],
      [ "Locked", "class_mad_level_manager_1_1_mad_level_property.html#aada9032835fed60f84e59f64f8b6783dad0f2e5376298c880665077b565ffd7dd", null ],
      [ "Completed", "class_mad_level_manager_1_1_mad_level_property.html#aada9032835fed60f84e59f64f8b6783da07ca5050e697392c9ed47e6453f1453f", null ],
      [ "LevelNumber", "class_mad_level_manager_1_1_mad_level_property.html#aada9032835fed60f84e59f64f8b6783daac89dfeb8ab92af9f58be71048d42b74", null ]
    ] ],
    [ "Type", "class_mad_level_manager_1_1_mad_level_property.html#af605164ac9fb7318773e3ab38f240b52", [
      [ "Bool", "class_mad_level_manager_1_1_mad_level_property.html#af605164ac9fb7318773e3ab38f240b52ac26f15e86e3de4c398a8273272aba034", null ],
      [ "Integer", "class_mad_level_manager_1_1_mad_level_property.html#af605164ac9fb7318773e3ab38f240b52aa0faef0851b4294c06f2b94bb1cb2044", null ],
      [ "Float", "class_mad_level_manager_1_1_mad_level_property.html#af605164ac9fb7318773e3ab38f240b52a22ae0e2b89e5e3d477f988cc36d3272b", null ],
      [ "String", "class_mad_level_manager_1_1_mad_level_property.html#af605164ac9fb7318773e3ab38f240b52a27118326006d3829667a400ad23d5d98", null ]
    ] ],
    [ "_propertyEnabled", "class_mad_level_manager_1_1_mad_level_property.html#acb96ece8e3c396c98bc23b973dbe784f", null ],
    [ "showWhenDisabled", "class_mad_level_manager_1_1_mad_level_property.html#aa15a26d2b218ed29bda90f9cf11310f3", null ],
    [ "showWhenEnabled", "class_mad_level_manager_1_1_mad_level_property.html#a91972eb5d8c278ab596bc87049858784", null ],
    [ "textFromProperty", "class_mad_level_manager_1_1_mad_level_property.html#a2a038bb4288f9dfc9e54fd054e86edff", null ],
    [ "textPropertyName", "class_mad_level_manager_1_1_mad_level_property.html#a7276aaa3f1e091770f61c3c860569a95", null ],
    [ "icon", "class_mad_level_manager_1_1_mad_level_property.html#ab0b10ad1adf2f8a46d939a6957af2ad1", null ],
    [ "propertyEnabled", "class_mad_level_manager_1_1_mad_level_property.html#a15d1df1b82fc3c9ddc7f060bf29ef305", null ],
    [ "propertySet", "class_mad_level_manager_1_1_mad_level_property.html#aea9f4df443fb93c1ccb98bec0bc37918", null ],
    [ "specialType", "class_mad_level_manager_1_1_mad_level_property.html#a30e56eaa66e6df607241065db1b225af", null ],
    [ "sprite", "class_mad_level_manager_1_1_mad_level_property.html#aac41088e6bd3ad353b9e85be099ee3c2", null ]
];