var class_mad_level_manager_1_1_mad_level_property_empty_tool =
[
    [ "icon", "class_mad_level_manager_1_1_mad_level_property_empty_tool.html#a3042263cf45f593d1914a3dd3fd4ec5e", null ],
    [ "name", "class_mad_level_manager_1_1_mad_level_property_empty_tool.html#ae318388cbfc7f9cd797f5d09099b3461", null ]
];