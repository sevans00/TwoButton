var class___n_a_m_e_s_p_a_c_e___1_1_mad_level =
[
    [ "Type", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level.html#a93086aecbf746c66413bce0a54e02f9d", [
      [ "Other", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level.html#a93086aecbf746c66413bce0a54e02f9da6311ae17c1ee52b36e68aaf4ad066387", null ],
      [ "Level", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level.html#a93086aecbf746c66413bce0a54e02f9daa0db49ba470c1c9ae2128c3470339153", null ],
      [ "Extra", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level.html#a93086aecbf746c66413bce0a54e02f9da8a398abbb120a35320a3d669ae71d92e", null ]
    ] ],
    [ "LevelPredicate", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level.html#a4dde1bc7525263ced0b5fb086754216f", null ]
];