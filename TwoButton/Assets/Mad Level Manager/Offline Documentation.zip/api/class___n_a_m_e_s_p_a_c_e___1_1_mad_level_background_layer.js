var class___n_a_m_e_s_p_a_c_e___1_1_mad_level_background_layer =
[
    [ "Align", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_background_layer.html#af64e0f3af946293bcd4832c3de24fc50", [
      [ "None", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_background_layer.html#af64e0f3af946293bcd4832c3de24fc50a6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Top", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_background_layer.html#af64e0f3af946293bcd4832c3de24fc50aa4ffdcf0dc1f31b9acaf295d75b51d00", null ],
      [ "Middle", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_background_layer.html#af64e0f3af946293bcd4832c3de24fc50ab1ca34f82e83c52b010f86955f264e05", null ],
      [ "Bottom", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_background_layer.html#af64e0f3af946293bcd4832c3de24fc50a2ad9d63b69c4a10a5cc9cad923133bc4", null ]
    ] ],
    [ "ScaleMode", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_background_layer.html#a13de2357be69a63242ca1b690a396819", [
      [ "Manual", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_background_layer.html#a13de2357be69a63242ca1b690a396819ae1ba155a9f2e8c3be94020eef32a0301", null ],
      [ "Fill", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_background_layer.html#a13de2357be69a63242ca1b690a396819adb3e3f51c9107e26c9bccf9a188ce2ed", null ]
    ] ],
    [ "Cleanup", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_background_layer.html#a22abb9941302ec4b3ebdf1fa24fb8b98", null ],
    [ "SetDirty", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_background_layer.html#a6aa9ec2ea3f2bdd3d21230e123a710ff", null ],
    [ "Update", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_background_layer.html#a1b91cbeb943a7344b89826d46454db74", null ],
    [ "align", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_background_layer.html#a7c19509cfe897e696d31b55ea66e22bd", null ],
    [ "followSpeed", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_background_layer.html#ab7457bf945d78aac6b3cb71e14de70b6", null ],
    [ "position", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_background_layer.html#a9dd8ade6b072c989ab2369ac46a95657", null ],
    [ "scale", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_background_layer.html#ab9bc8f6b76caa1910e2f6f7dfba7586e", null ],
    [ "scaleMode", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_background_layer.html#a4f42d1da671a469cc659cfc815249292", null ],
    [ "scrollSpeed", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_background_layer.html#a066cf6ebe9956b8e95a92e9573ff2acc", null ],
    [ "ScrollSpeedMultiplier", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_background_layer.html#a4ebc68e0cde66e29f3654e403ac16f01", null ],
    [ "texture", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_background_layer.html#a63e27e5d030fe134fa787b38789d2bca", null ],
    [ "tint", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_background_layer.html#a3a7cb7bc1f929e9bd6dbaeb2cae62be3", null ],
    [ "parent", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_background_layer.html#a7f3d3a1865cd1c67b41ded50eea9eee9", null ],
    [ "root", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_background_layer.html#a9c897bb0354328a6d875baf494e89d23", null ],
    [ "sprite", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_background_layer.html#aacd938448bdd1b9150f86a0e14bfc073", null ]
];