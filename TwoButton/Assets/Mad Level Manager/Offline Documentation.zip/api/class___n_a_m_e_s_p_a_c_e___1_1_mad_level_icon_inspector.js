var class___n_a_m_e_s_p_a_c_e___1_1_mad_level_icon_inspector =
[
    [ "OnEnable", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_icon_inspector.html#a5ab18d883e1e8b7370bc79d227fa5d07", null ],
    [ "OnInspectorGUI", "class___n_a_m_e_s_p_a_c_e___1_1_mad_level_icon_inspector.html#aa4f95e4c6728edabbe43d7b91d3a4234", null ]
];