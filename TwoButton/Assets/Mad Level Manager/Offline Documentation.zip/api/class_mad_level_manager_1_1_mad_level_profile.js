var class_mad_level_manager_1_1_mad_level_profile =
[
    [ "DefaultProfile", "class_mad_level_manager_1_1_mad_level_profile.html#a0fa5788b0ec85d7656d204b7968dd6a3", null ]
];