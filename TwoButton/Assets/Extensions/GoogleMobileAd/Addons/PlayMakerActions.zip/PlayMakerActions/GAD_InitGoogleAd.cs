﻿////////////////////////////////////////////////////////////////////////////////
//  
// @module Android Native Plugin for Unity3D 
// @author Osipov Stanislav (Stan's Assets) 
// @support stans.assets@gmail.com 
//
////////////////////////////////////////////////////////////////////////////////

using UnityEngine;
using System.Collections;



namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Google Mobile Ad")]
	public class GAD_InitGoogleAd : FsmStateAction {


		public FsmString IOS_BannersAdunityId;
		public FsmString IOS_InterstisialsAdunityId;

		public FsmString ANDROID_BannersAdunityId;
		public FsmString ANDROID_InterstisialsAdunityId;


		public override void OnEnter() {
			GoogleMobileAd.Init(ANDROID_BannersAdunityId.Value, IOS_BannersAdunityId.Value);
			GoogleMobileAd.SetInterstisialsUnitID(ANDROID_InterstisialsAdunityId.Value, IOS_InterstisialsAdunityId.Value);
			Finish();
		}



		
	}
}
