package com.androidnative.features.ad;

import java.util.HashMap;

import android.app.Activity;
import android.util.Log;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;



public class ANMobileAd extends AdListener  {
	
	public static String AD_MOB_LISTNER_NAME = "AndroidAdMobController";
	
	private String AD_UNIT_ID = "";
	private String INTERSTISIALS_AD_UNIT_ID = "";
	
	
	private static ANMobileAd _instance = null;

	private static Activity mainActivity = null;
	private static AdRequest.Builder adRequestBuilder = null;
	
	
	private static HashMap<Integer, GADBanner> banners;
	
	
	
	private InterstitialAd interstitial = null;
	private InterstitialAdListner intListner = null;
	
	private boolean IsInited = false;
	
	
	
	public static ANMobileAd GetInstance() {
		if(_instance == null) {
			_instance =  new ANMobileAd();
			banners = new HashMap<Integer, GADBanner>();
		}
		
		
		return _instance;
	}
	
	
	
	public void Init(String ad_unit_id, Activity activity) {
		if(IsInited) {
			return;
		}
		
		IsInited = true;
		
		
		AD_UNIT_ID = ad_unit_id;
		INTERSTISIALS_AD_UNIT_ID = ad_unit_id;
		mainActivity = activity;
		adRequestBuilder =  new AdRequest.Builder();
		
		Log.d("AndroidNative", "Init ");
	}
	
	public void ChangeBannersUnitID(String ad_unit_id) {
		AD_UNIT_ID = ad_unit_id;
	}
	
	
	public void ChangeInterstisialsUnitID(String ad_unit_id) {
		INTERSTISIALS_AD_UNIT_ID = ad_unit_id;
		if(interstitial != null)  {
			interstitial.setAdUnitId(INTERSTISIALS_AD_UNIT_ID);
		}
	}
	
	
	public void AddKeyword(String keyword) {
		 if(!IsInited) {
			return;
		 }
		 
		 adRequestBuilder.addKeyword(keyword);
	}
	

	public void AddTestDevice(String deviceId) {
		 if(!IsInited) {
			return;
		 }
			 
		 adRequestBuilder.addTestDevice(deviceId);
	}
	
	public void SetGender(int gender) {
		 if(!IsInited) {
			return;
		 }
			 
		 adRequestBuilder.setGender(gender);
	}
	
	
	public void CreateBannerAd(int gravity, int size, int id) {
		

	 	 if(!IsInited) {
			return;
		 }
	
	 	Log.d("AndroidNative", "CreateBannerAd ");
	 	
	 	GADBanner banner = new GADBanner(gravity, size, id);
	 	banners.put(id, banner);


	}
	
	public void CreateBannerAd(int x, int y, int size, int id) {
		

	 	 if(!IsInited) {
			return;
		 }
	
	 	Log.d("AndroidNative", "CreateBannerAd ");
	 	
	 	GADBanner banner = new GADBanner(x, y, size, id);
	 	banners.put(id, banner);


	}
	
	public void DestroyBanner(int bannerId) {

		if(banners.containsKey(bannerId)) {
			GADBanner banner = banners.get(bannerId);
			banner.Destroy();
			banners.remove(bannerId);
		} else {
			Log.d("AndroidNative", "Banner with id: " + bannerId + " not found");
		}
	
	}
	
	
	private void InitInterstitialAd(Activity activity, String id) {
		if(interstitial == null) {
			Log.d("AndroidNative", "InitInterstitialAd: ");
			interstitial = new InterstitialAd(activity);
		    interstitial.setAdUnitId(id);
		    
		    intListner =  new InterstitialAdListner(interstitial);
			interstitial.setAdListener(intListner);
		}
	}
	
	
	public void StartInterstitialAd() {
		InitInterstitialAd(mainActivity, INTERSTISIALS_AD_UNIT_ID);

		intListner.IsShowAdOnLoad = true;
		AdRequest adRequest = new AdRequest.Builder().build();
	    interstitial.loadAd(adRequest);
	    

	}
	
	
	public void LoadInterstitialAd() {
		InitInterstitialAd(mainActivity, INTERSTISIALS_AD_UNIT_ID);

		intListner.IsShowAdOnLoad = false;
		AdRequest adRequest = new AdRequest.Builder().build();
	    interstitial.loadAd(adRequest);
	}
	
	public void ShowInterstitialAd() {
		if(interstitial != null) {
			interstitial.show();
		} 
		
	}
	
	
	
	public void HideAd(int bannerId) {
		if(banners.containsKey(bannerId)) {
			GADBanner banner = banners.get(bannerId);
			banner.HideAd();
		} else {
			Log.d("AndroidNative", "Banner with id: " + bannerId + " not found");
		}
	}
	
	public void ShowAd(int bannerId) {
		if(banners.containsKey(bannerId)) {
			GADBanner banner = banners.get(bannerId);
			banner.ShowAd();
		} else {
			Log.d("AndroidNative", "Banner with id: " + bannerId + " not found");
		}
	}
	
	
	public void Refresh(int bannerId) {
		if(banners.containsKey(bannerId)) {
			GADBanner banner = banners.get(bannerId);
			banner.Refresh();
		} else {
			Log.d("AndroidNative", "Banner with id: " + bannerId + " not found");
		}
	}
	

	
	public  Activity GetCurrentActivity() {
		return mainActivity;
	}
	
	public String GetAdUnitID() {
		return AD_UNIT_ID; 
	}
	
	public AdRequest.Builder GetAdRequestBuilder() {
		return adRequestBuilder;
	}

	

}

