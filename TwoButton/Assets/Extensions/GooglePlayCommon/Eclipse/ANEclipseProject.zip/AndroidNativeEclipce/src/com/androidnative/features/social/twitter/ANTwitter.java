package com.androidnative.features.social.twitter;



import java.io.File;

import com.unity3d.player.UnityPlayer;

import twitter4j.StatusUpdate;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.User;
import twitter4j.auth.AccessToken;
import twitter4j.auth.RequestToken;
import twitter4j.conf.Configuration;
import twitter4j.conf.ConfigurationBuilder;
import twitter4j.json.DataObjectFactory;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;

public class ANTwitter {
	
	public static boolean IsInited = false;
	public static boolean IsLogged = false;
	
	   // Preference Constants
    static String PREFERENCE_NAME = "twitter_oauth";
    static final String PREF_KEY_OAUTH_TOKEN = "oauth_token";
    static final String PREF_KEY_OAUTH_SECRET = "oauth_token_secret";
    
    static final String PREF_KEY_TWITTER_LOGIN = "isTwitterLogedIn";
 
    public static final String TWITTER_CALLBACK_URL = "oauth://androidnative";
 
    // Twitter oauth urls
    static final String URL_TWITTER_AUTH = "auth_url";
    static final String URL_TWITTER_OAUTH_VERIFIER = "oauth_verifier";
    static final String URL_TWITTER_OAUTH_TOKEN = "oauth_token";
    
    
    // Twitter
    private static Twitter twitter = null;
    private static RequestToken requestToken;
    
    private static  Uri uri;
    private static AccessToken accessToken;
    
    
    private static String TWITTER_CONSUMER_KEY = "wEvDyAUr2QabVAsWPDiGwg";
    private static String TWITTER_CONSUMER_SECRET = "igRxZbOrkLQPNLSvibNC3mdNJ5tOlVOPH3HNNKDY0";
    
    
	private final String UNITY_LISTNER_NAME = "AndroidTwitterManager";
//	private final String UNITY_SPLITTER = "|";
    
    // Shared Preferences
    private static SharedPreferences mSharedPreferences;
    // Progress dialog
    ProgressDialog pDialog;
    //Activity main
    private Activity mainActivity;
    
    private File attchment = null;
    private static boolean  postFailed = false;
    
    
    private static ANTwitter _instance = null;
    

    
    
    
	public static ANTwitter GetInstance() {
		if(_instance == null) {
			_instance =  new ANTwitter();
		}
		
		return _instance;
	}
	
	
	
	public void Init(String consumer_key, String consumer_secret, Activity act) {
		TWITTER_CONSUMER_KEY = consumer_key;
		TWITTER_CONSUMER_SECRET = consumer_secret;
		mainActivity = act;
		
		Log.d("AndroidNative", "Twitter Init: ");
		
		 // Shared Preferences
        mSharedPreferences = mainActivity.getApplicationContext().getSharedPreferences("MyPref", 0);

        
        ConfigurationBuilder builder = new ConfigurationBuilder();
        builder.setOAuthConsumerKey(TWITTER_CONSUMER_KEY);
        builder.setOAuthConsumerSecret(TWITTER_CONSUMER_SECRET);
        builder.setJSONStoreEnabled(true);
        
        
        String authState = "0";
        if (isTwitterLoggedInAlready()) {
        	authState = "1";
        	Log.d("AndroidNative", "Twitter auth true ");

           // Access Token 
            String access_token = mSharedPreferences.getString(PREF_KEY_OAUTH_TOKEN, "");
            // Access Token Secret
            String access_token_secret = mSharedPreferences.getString(PREF_KEY_OAUTH_SECRET, "");
             
            accessToken = new AccessToken(access_token, access_token_secret);
            twitter = new TwitterFactory(builder.build()).getInstance(accessToken);
            
            

        } else {
        	Log.d("AndroidNative", "Twitter auth false ");

            Configuration configuration = builder.build();
             
            TwitterFactory factory = new TwitterFactory(configuration);
            twitter = factory.getInstance();
        }
        
        
        UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnInited", authState);
        
        IsInited = true;
	}
	
	
	public void SetIntent(Intent intent) {
		
		
		uri = intent.getData();
		Log.d("AndroidNative", "OnActivityStart ");
		if (uri == null) {
			return;
		}
		
		if (!uri.toString().startsWith(ANTwitter.TWITTER_CALLBACK_URL)) {
			return;
		}
		
		
		Log.d("AndroidNative", "TWITTER_CALLBACK_URL ");
    	new Thread(new Runnable() {
			
			@Override
			public void run() {
				 // oAuth verifier
	            String verifier = uri.getQueryParameter(URL_TWITTER_OAUTH_VERIFIER);
	            Log.d("AndroidNative", "run ");
	            try {
	            	//requestToken = twitter.getOAuthRequestToken(TWITTER_CALLBACK_URL);
	                // Get the access token
	                accessToken = twitter.getOAuthAccessToken(requestToken, verifier);
	 
	                // Shared Preferences
	                Editor e = mSharedPreferences.edit();
	 
	                // After getting access token, access token secret
	                // store them in application preferences
	                e.putString(PREF_KEY_OAUTH_TOKEN, accessToken.getToken());
	                e.putString(PREF_KEY_OAUTH_SECRET,accessToken.getTokenSecret());
	                // Store login status - true
	                e.putBoolean(PREF_KEY_TWITTER_LOGIN, true);
	                e.commit(); // save changes
	 
	                Log.d("AndroidNative", "Twitter OAuth Token> " + accessToken.getToken());
	                
	                UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnAuthSuccess", "");
	              

	            } catch (Exception e) {
	                // Check log for login errors
	            	UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnAuthFailed", "");
	                Log.e("AndroidNative", "Twitter Login Error> " + e.getMessage());
	                logoutFromTwitter();
	            }
			}
		}).start();
    	
    	
	}
	
	
	
	
	public void LoadUserData() {

		Log.d("AndroidNative", " LoadUserData ");
		
		if(!isTwitterLoggedInAlready()) {
			return;
		}
		
		new Thread(new Runnable() {	
			@Override
			public void run() {
				try {
					long userID = accessToken.getUserId();
					 
					Log.d("AndroidNative", Long.toString(userID));
					
					User user = null;
				
					user = twitter.showUser(userID);
					 
					  
					 // Displaying user data
					String  JSON = DataObjectFactory.getRawJSON(user);
					Log.d("AndroidNative",  JSON);
					
					UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnUserDataLoaded", JSON);
					   
				
				} catch (TwitterException e) {
					
					UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnUserDataLoadFailed", "");
					
					e.printStackTrace();
					Log.e("AndroidNative", e.getErrorMessage());
				}
			} 
			
		}).start();
		
		
		
	}
	
	
	public void Twitt(String status) {
		Twitt(status, null);
	}
	
	
	public void Twitt(String status, File media) {
		Log.d("AndroidNative", " Twitt ");
		
		attchment = media;
		postFailed = false;
		new updateTwitterStatus().execute(status);
	}
	
	

	
	
	public void AuthificateUser() {
		
		Log.d("AndroidNative", "AuthificateUser ");
		
		new Thread(new Runnable() {	
			@Override
			public void run() {
				if(isTwitterLoggedInAlready()) {
					UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnAuthSuccess", "");
				} else {
					StartUserAuth();
				}
				
			} 
			
		}).start();
	}
	
	public void logoutFromTwitter() {
		Log.d("AndroidNative", "logoutFromTwitter ");
		// Clear the shared preferences
		Editor e = mSharedPreferences.edit();
		e.remove(PREF_KEY_OAUTH_TOKEN);
		e.remove(PREF_KEY_OAUTH_SECRET);
		e.remove(PREF_KEY_TWITTER_LOGIN);
		e.commit();
		
		Init(TWITTER_CONSUMER_KEY, TWITTER_CONSUMER_SECRET, mainActivity);
		
	}
	
	
	
	
	
	
	private void StartUserAuth() {
        try {
     
        	Log.d("AndroidNative", "StartUserAuth ");
      
            requestToken = twitter.getOAuthRequestToken(TWITTER_CALLBACK_URL);
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(requestToken.getAuthenticationURL()));
 
			mainActivity.startActivity(i);
        } catch (TwitterException e) {
        	UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnAuthFailed", "");
            e.printStackTrace();
            
            Log.d("AndroidNative", "TwitterException ");
            
            if (e.getStatusCode() == -1) {
            	Log.d("AndroidNative", "logoutFromTwitter ");
                // This is the case when the developer who created the application has revoked the application permission.
                // In this case we need to remove stored access token as it is no longer valid.
                // Logging in again will fetch newer accesstoken and will solve the problem.
            	 //logoutFromTwitter();
                // StartUserAuth();
            }
            
           
        }
    }
	
	
    private boolean isTwitterLoggedInAlready() {
        // return twitter login status from Shared Preferences
        return mSharedPreferences.getBoolean(PREF_KEY_TWITTER_LOGIN, false);
    }

    /**
     * Function to update status
     * */
    class updateTwitterStatus extends AsyncTask<String, String, String> {
     
        /**
         * Before starting background thread Show Progress Dialog
         * */
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(mainActivity);
            pDialog.setMessage("Updating to twitter...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.show();
        }
     
        /**
         * getting Places JSON
         * */
        protected String doInBackground(String... args) {
        	Log.d("AndroidNative", args[0]);
            String message = args[0];
            try {
 
                StatusUpdate status = new StatusUpdate(message);
                if(attchment != null) {
                	Log.d("AndroidNative", "post witg attachment");
                	status.setMedia(attchment);
                }
                twitter.updateStatus(status);
                
                 
              
            } catch (TwitterException e) {
                // Error in updating status
            	postFailed = true;
                Log.d("AndroidNative", e.getMessage());
            }
            return null;
        }
     
        /**
         * After completing background task Dismiss the progress dialog and show
         * the data in UI Always use runOnUiThread(new Runnable()) to update UI
         * from background thread, otherwise you will get error
         * **/
        protected void onPostExecute(String file_url) {
            // dismiss the dialog after getting all products
            pDialog.dismiss();
            if(postFailed) {
            	UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnPostFailed", "");
            } else {
            	UnityPlayer.UnitySendMessage(UNITY_LISTNER_NAME, "OnPostSuccess", "");
            }
            Log.d("AndroidNative", "Posted");
            
        }
     
    }
	
}
