package com.androidnative.gcm.network;

import java.util.ArrayList;
import java.util.List;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.androidnative.AndroidNativeBridge;
import com.androidnative.gms.core.GameClientManager;
import com.androidnative.gms.core.NewGameHelper;
import com.androidnative.gms.listeners.network.AN_RealTimeMessageReceivedListener;
import com.androidnative.gms.listeners.network.AN_RoomStatusUpdateListener;
import com.androidnative.gms.listeners.network.AN_RoomUpdateListener;
import com.google.android.gms.games.Games;
import com.google.android.gms.games.GamesActivityResultCodes;
import com.google.android.gms.games.Player;
import com.google.android.gms.games.multiplayer.Participant;
import com.google.android.gms.games.multiplayer.realtime.Room;
import com.google.android.gms.games.multiplayer.realtime.RoomConfig;
import com.unity3d.player.UnityPlayer;

public class RealTimeMultiplayerController {
	
	
	protected NewGameHelper mHelper;

	private static RealTimeMultiplayerController _instance = null;
	public Room currentRoom;  
	
	
	

	public static RealTimeMultiplayerController GetInstance() {
		if (_instance == null) {
			_instance = new RealTimeMultiplayerController();
		}

		return _instance;
	}
	
	
	// --------------------------------------
	// DELAGETD FROM GCM
	// --------------------------------------
	
	public void SetGameHelper(NewGameHelper helper) {
		mHelper  = helper;
	}
    
	
	public void OnStop() {
		//leaveRoom("OnGameCanceled");
	}
	
	/*
	public void onConnected(Bundle connectionHint)  {

		// register listener so we are notified if we receive an invitation to
		// play
		// while we are in the game
		Games.Invitations.registerInvitationListener(mHelper.getGoogleApiClient(), this);

		// if we received an invite via notification, accept it; otherwise, go
		// to main screen
		if (getInvitationId() != null) {
			acceptInviteToRoom(getInvitationId());
			return;
		}
	}
	
	*/
	public void onActivityResult(int request, int response, Intent data) {
		switch (request) {
        case GameClientManager.RC_SELECT_PLAYERS:        	
        	//handleSelectPlayersResult(response, data);
        	break;
        case GameClientManager.RC_INVITATION_INBOX:
        	//handleInvitationInboxResult(response, data);
        	break;
        case GameClientManager.RC_WAITING_ROOM:
        	
        	switch(response) {
	        	case Activity.RESULT_OK: 
	        	case Activity.RESULT_CANCELED:
	        		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnWatingRoomIntentClosed", String.valueOf(response) );
	        		break;
	        		
	        	case GamesActivityResultCodes.RESULT_LEFT_ROOM:
	        		LeaveRoom();
	        		break;
	        	
        	}
        
        	break;
		}
	}
	
	
	// --------------------------------------
	// PUBLIC METHODS
	// --------------------------------------
	
	
	public void findMatch(int minPlayers, int maxPlayers, int bitMask) {
		Log.d("GAME_CLIENT_MANAGER findMatch!!!", "dida FIND MATCH");
		Bundle autoMatchCriteria = RoomConfig.createAutoMatchCriteria(minPlayers, maxPlayers, bitMask);
		RoomConfig.Builder roomConfigBuilder = makeBasicRoomConfigBuilder();
		roomConfigBuilder.setAutoMatchCriteria(autoMatchCriteria);
		Games.RealTimeMultiplayer.create(mHelper.getGoogleApiClient(), roomConfigBuilder.build());
	}
	
	private RoomConfig.Builder makeBasicRoomConfigBuilder() {
		return RoomConfig.builder(new AN_RoomUpdateListener()).setMessageReceivedListener(new AN_RealTimeMessageReceivedListener()).setRoomStatusUpdateListener(new AN_RoomStatusUpdateListener());
	}
	
	@SuppressLint("NewApi")
	public void showWaitingRoomIntent() {
		// minimum number of players required for our game
		// For simplicity, we require everyone to join the game before we start
		// it (this is signaled by Integer.MAX_VALUE).
		final int MIN_PLAYERS = Integer.MAX_VALUE;
		Intent data = Games.RealTimeMultiplayer.getWaitingRoomIntent(mHelper.getGoogleApiClient(), currentRoom, MIN_PLAYERS);

		// show waiting room UI
		 AndroidNativeBridge.GetInstance().startActivityForResult(data, GameClientManager.RC_WAITING_ROOM);
	}
	
	
	// --------------------------------------
	// PRIVATE METHODS
	// --------------------------------------
	
	
	public void sendDataToAll(String data, int sendType) {
		Log.d("GAMECLIENTMANAGER BYTE DATA!!!!!", data);
		byte[] stateData = ConvertStringToMultiplayerData(data);
				
		sendMessage(stateData, currentRoom.getParticipants(), sendType);
	}

	public void sendDataToPlayers(String data, String players, int sendType) {
		byte[] stateData = ConvertStringToMultiplayerData(data);
		
		
		ArrayList<Participant> participants =  new ArrayList<Participant>();
		
		if(players != null && players.length() > 0) {
			for(String id : players.split(AndroidNativeBridge.UNITY_SPLITTER)) {
				
				for (Participant p : currentRoom.getParticipants()) {
					if(p.getPlayer().getPlayerId().equals(id)) {
						participants.add(p);
					}
				}
			}
		}
			
		
		sendMessage(stateData, participants, sendType);
		
	}
	
	
	private void sendMessage(byte[] data, ArrayList<Participant> participants, int sendType) {
		
		if(currentRoom == null) {
			return;
		}

		Player player = Games.Players.getCurrentPlayer(mHelper.getGoogleApiClient());
		
		for (Participant p : currentRoom.getParticipants()) {
			if (p.getParticipantId().equals(player.getPlayerId()))
				continue;
			if (p.getStatus() != Participant.STATUS_JOINED)
				continue;
			
			
			
			if(sendType == 0) {
				Games.RealTimeMultiplayer.sendReliableMessage(mHelper.getGoogleApiClient(), null, data, currentRoom.getRoomId(), p.getParticipantId());
			} else {
				Games.RealTimeMultiplayer.sendUnreliableMessage(mHelper.getGoogleApiClient(), data, currentRoom.getRoomId(), p.getParticipantId());
			}
			
			
		}
	}
	
	
	
	// --------------------------------------
	// EVENTS
	// --------------------------------------
	
	public void OnRoomUpdated(Room room) {
		currentRoom = room;
		
		StringBuilder info = new StringBuilder();
		
		info.append(room.getRoomId() );
		info.append(AndroidNativeBridge.UNITY_SPLITTER);
		
		info.append(room.getCreatorId() );
		info.append(AndroidNativeBridge.UNITY_SPLITTER);
		
		String ParticipantIds = "";
		
		boolean first = true;
		for(String id : room.getParticipantIds()) {
			if(first) {
				first = false;
				ParticipantIds += id;
			} else {
				ParticipantIds += "," + id;
			}
			
			AndroidNativeBridge.GetInstance().loadPlayerInfo(id);
		}
		
		info.append(ParticipantIds);
		info.append(AndroidNativeBridge.UNITY_SPLITTER);

		info.append(room.getStatus());
		info.append(AndroidNativeBridge.UNITY_SPLITTER);
		info.append(room.getCreationTimestamp());
		info.append(AndroidNativeBridge.UNITY_SPLITTER);
		
				
		
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnRoomUpdate", info.toString());
		
		
	}
	
	public void LeaveRoom() {
		if (currentRoom != null) {
			Games.RealTimeMultiplayer.leave(mHelper.getGoogleApiClient(), null, currentRoom.getRoomId());
			currentRoom = null;
		}	
		
	}
	
	
	
	
	private static byte[] ConvertStringToMultiplayerData(String data) {
		String[] array = data.split(",");
		List<Byte> l = new ArrayList<Byte>();
		for (String b : array) {
			int temp_param = Integer.valueOf(b);
			byte byte_value = (byte)temp_param;
			l.add(Byte.valueOf(String.valueOf(byte_value)));
		}

		Byte[] B = l.toArray(new Byte[l.size()]);

		byte[] stateData = new byte[B.length];
		for (int i = 0; i < B.length; i++) {
			stateData[i] = B[i];
		}

		return stateData;
	}

	
	

	
	
}
