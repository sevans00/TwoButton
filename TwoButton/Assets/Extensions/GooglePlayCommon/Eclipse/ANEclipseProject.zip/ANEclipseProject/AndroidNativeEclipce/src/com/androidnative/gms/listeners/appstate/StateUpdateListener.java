package com.androidnative.gms.listeners.appstate;

import android.util.Log;

import com.androidnative.AndroidNativeBridge;
import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.appstate.AppStateManager;
import com.google.android.gms.appstate.AppStateManager.StateConflictResult;
import com.google.android.gms.appstate.AppStateManager.StateLoadedResult;
import com.google.android.gms.appstate.AppStateManager.StateResult;
import com.google.android.gms.common.api.ResultCallback;
import com.unity3d.player.UnityPlayer;

public class StateUpdateListener  implements ResultCallback<AppStateManager.StateResult>{

	@Override
	public void onResult(StateResult arg0) {
		// TODO Auto-generated method stub
		
		if(arg0.getConflictResult() != null) {
			onStateConflict(arg0.getConflictResult());
		}
		
		if(arg0.getLoadedResult() != null) {
			onStateLoad(arg0.getLoadedResult());
		}
		
		
	}
	
	private void onStateConflict(StateConflictResult res) {
		int stateKey = res.getStateKey();
		
		String dataLocal = GameClientManager.ConvertCloudDataToString(res.getLocalData());
		String dataServer = GameClientManager.ConvertCloudDataToString(res.getServerData());
		Log.d("AndroidNative", "onStateConflict Status:  stateKey: " + stateKey);
		

		StringBuilder result = new StringBuilder();
		result.append(stateKey);
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		result.append(dataLocal);
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		result.append(dataServer);
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		result.append(res.getResolvedVersion());
		UnityPlayer.UnitySendMessage( GameClientManager.GOOGLE_CLOUD_LISTNER_NAME, "OnStateConflict", result.toString());
	}
	
	private void onStateLoad(StateLoadedResult res) {
		int stateKey = res.getStateKey();
		int statusCode = res.getStatus().getStatusCode();
		String data = "";
		Log.d("AndroidNative","onStateLoaded Status: " + statusCode + " stateKey: " + stateKey);
		
		data = GameClientManager.ConvertCloudDataToString(res.getLocalData());
	

		StringBuilder result = new StringBuilder();
		result.append(statusCode);
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		result.append(stateKey);
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		result.append(data);
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_CLOUD_LISTNER_NAME, "OnStateResolved", result.toString());
	}

	

}
