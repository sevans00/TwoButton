package com.androidnative.gcm;

import java.io.IOException;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;

import com.androidnative.AndroidNativeBridge;
import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.unity3d.player.UnityPlayer;

public class ANCloudMessageService {

	public static final String PROPERTY_MESSAGE = "property_message";
	public static final String MESSAGE_SERVICE_LISTNER_NAME = "GoogleCloudMessageService";

	private GoogleCloudMessaging gcm;
	private String regid;

	private String SENDER_ID = "Your-Sender-ID";

	private static ANCloudMessageService _inctance = null;

	/**
	 * Tag used on log messages.
	 */
	static final String TAG = "AndroidNative";

	public static ANCloudMessageService GetInstance() {
		if (_inctance == null) {
			_inctance = new ANCloudMessageService();
		}

		return _inctance;
		
		
	}

	public ANCloudMessageService() {
		gcm = GoogleCloudMessaging.getInstance(AndroidNativeBridge
				.GetInstance());
	}

	@SuppressLint("NewApi")
	public void LoadLastMessage() {
		SharedPreferences mSharedPreferences = AndroidNativeBridge.GetInstance().getApplicationContext().getSharedPreferences("MyPref", 0);
   	 	String MessgaeJSON = mSharedPreferences.getString(PROPERTY_MESSAGE, "");
   	 	UnityPlayer.UnitySendMessage(MESSAGE_SERVICE_LISTNER_NAME, "OnLastMessageLoaded", MessgaeJSON);	
	}

	public void registerDevice(String senderId) {
		
		if (AndroidNativeBridge.GetInstance().checkPlayServices()) {
			SENDER_ID = senderId;
			registerInBackground();
		} else {
			Log.i(TAG, "No valid Google Play Services APK found.");
			UnityPlayer.UnitySendMessage(MESSAGE_SERVICE_LISTNER_NAME,
					"OnRegistrationFailed", "");
		}
		
	}

	/**
	 * Registers the application with GCM servers asynchronously.
	 * <p>
	 * Stores the registration ID and the app versionCode in the application's
	 * shared preferences.
	 */
	private void registerInBackground() {
		new AsyncTask<Void, Void, String>() {
			@Override
			protected String doInBackground(Void... params) {
				String msg = "";
				try {
					regid = gcm.register(SENDER_ID);
					msg = "Registration ID = " + regid;

					// You should send the registration ID to your server over
					// HTTP, so it
					// can use GCM/HTTP or CCS to send messages to your app.
					sendRegistrationIdToBackend();

				} catch (IOException ex) {
					msg = "Error :" + ex.getMessage();
					Log.i(TAG, "registerInBackground error.");
					// If there is an error, don't just keep trying to register.
					// Require the user to click a button again, or perform
					// exponential back-off.

					UnityPlayer.UnitySendMessage(MESSAGE_SERVICE_LISTNER_NAME,
							"OnRegistrationFailed", "");
				}
				return msg;
			}

			@Override
			protected void onPostExecute(String msg) {
				Log.i(TAG, "GCM: SENDER ID: " + SENDER_ID);
				Log.i(TAG, "GCM: " + msg);
			}
		}.execute(null, null, null);
	}

	/**
	 * Sends the registration ID to your server over HTTP, so it can use
	 * GCM/HTTP or CCS to send messages to your app. Not needed for this demo
	 * since the device sends upstream messages to a server that echoes back the
	 * message using the 'from' address in the message.
	 */
	private void sendRegistrationIdToBackend() {
		UnityPlayer.UnitySendMessage(MESSAGE_SERVICE_LISTNER_NAME,
				"OnRegistrationReviced", regid);
	}
}
