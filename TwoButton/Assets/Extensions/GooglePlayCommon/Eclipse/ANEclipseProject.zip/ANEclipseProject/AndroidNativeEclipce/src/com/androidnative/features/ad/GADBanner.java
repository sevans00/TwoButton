package com.androidnative.features.ad;

import android.annotation.SuppressLint;
import android.util.Log;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.androidnative.AndroidNativeBridge;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;

@SuppressLint("NewApi") 
public class GADBanner {

	private int _id;
	private LinearLayout layout = null;
	private AdView adView = null;
	
	
	
	public GADBanner(int x, int y, int size, int id) {
		this(Gravity.TOP, size, id);
		layout.setX(x);
		layout.setY(y);
		
	}
	
	
	public GADBanner(int gravity, int size, int id) {
		
		_id = id;
		
		
		 adView = new AdView(ANMobileAd.GetInstance().GetCurrentActivity());
		 adView.setAdUnitId(ANMobileAd.GetInstance().GetAdUnitID());
		 adView.setAdSize( intSizeToAdSize(size) );
	   
	     
	    layout = new LinearLayout(ANMobileAd.GetInstance().GetCurrentActivity());
		layout.setGravity(gravity);
		layout.addView(adView, new RelativeLayout.LayoutParams(-2, -2));
		 
	  
		
	
	   
	    adView.setAdListener(new BannerAdListner(adView, _id));	
	    adView.setInAppPurchaseListener(new AdInAppListner());
	    
	    Refresh();
	   
	}
	
	/**
	 * By nastrandsky
	 * Sets the position of a banner without destroying it based on a gravity.
	 * @param gravity
	 */
	public void SetPosition(int gravity) {
		if(layout != null) {
			layout.setGravity(gravity);
		}
	}
	
	/**
	 * By nastrandsky
	 * Sets the position of a banner without destroying it based on X and Y coordinates.
	 * @param gravity
	 */
	public void SetPosition(int x, int y) {
		if(layout != null) {
			layout.setGravity(Gravity.TOP);
			layout.setX(x);
			layout.setY(y);
		}
	}
	
	
	
	public void HideAd() {
		if(layout.getParent() != null) {
			ViewGroup vg = (ViewGroup)(layout.getParent());
			vg.removeView(layout);
		}
		
	}
	
	public void ShowAd() {
		if(layout.getParent() == null) {
			ANMobileAd.GetInstance().GetCurrentActivity().addContentView(layout, new RelativeLayout.LayoutParams(-1, -1));
		}
		
	}
	
	
	public void Refresh() {
	
		AdRequest request = ANMobileAd.GetInstance().GetAdRequestBuilder().build();
		Log.d("AndroidNative", "Is Test Device: " +  String.valueOf ( request.isTestDevice(AndroidNativeBridge.GetInstance())   )  );
		
		
		adView.loadAd(request);
	}
	
	public void Destroy() {
		HideAd();
		
		adView.destroy();
		adView = null;
		layout = null;
	}
	
	
	
	private static AdSize intSizeToAdSize(int intSize) {
	    switch(intSize) {
	     case 1:
	    	 return AdSize.BANNER;
	     case 2:
	    	 return AdSize.SMART_BANNER;
	     case 3:
	    	 return AdSize.FULL_BANNER;
	     case 4:
	    	 return AdSize.LEADERBOARD;
	     case 5:
	    	 return AdSize.MEDIUM_RECTANGLE;
	     default:
	    	 return AdSize.BANNER;
	    }
	}
	
	
}
