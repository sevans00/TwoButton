﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native")]
	public class PlayServiceShowLeaderboardUIAction : FsmStateAction {

		
		public override void Reset() {
			
		}


		public override void OnEnter() {
			GooglePlayManager.instance.showLeaderBoardsUI();
			Finish();
		}

	}
}

