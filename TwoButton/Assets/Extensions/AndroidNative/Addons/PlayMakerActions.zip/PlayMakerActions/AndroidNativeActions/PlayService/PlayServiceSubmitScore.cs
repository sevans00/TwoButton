﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native")]
	public class PlayServiceSubmitScore : FsmStateAction {

		public string leaderboardId;
		public FsmInt score;


		public override void OnEnter() {
			GooglePlayManager.instance.submitScoreById(leaderboardId, score.Value);
			Finish();
			
		}

	}
}

