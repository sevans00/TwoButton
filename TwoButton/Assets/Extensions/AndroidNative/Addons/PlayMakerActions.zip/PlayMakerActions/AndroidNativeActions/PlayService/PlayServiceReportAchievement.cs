﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native")]
	public class PlayServiceReportAchievement : FsmStateAction {

		public string achivmentId;



		public override void OnEnter() {
			GooglePlayManager.instance.reportAchievementById(achivmentId);
			Finish();
		}

	}
}

