﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native")]
	public class AndroidNativeMessagePopUpAction : FsmStateAction {
		
		public string title 	= "Like this game?";
		public string message   = "Please rate to support future updates!";




		
		
		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Finish();
				return;
			}

			AndroidMessage msg = AndroidMessage.Create(title, message);
			msg.addEventListener(BaseEvent.COMPLETE, OnComplete);
			
		}


		private void OnComplete(CEvent e) {
			Finish();
		}



		
	}
}


