﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native")]
	public class AndroidNativeRatePopUpAction : FsmStateAction {
		
		public string title 	= "Like this game?";
		public string message   = "Please rate to support future updates!";

		public string yes 	 = "Okay";
		public string no	 = "No";

		public FsmEvent yesEvent;
		public FsmEvent noEvent;

		[Tooltip("Result will be fired in unity Editor")]
		public AndroidDialogResult ResultInEditor = AndroidDialogResult.YES;

		
		
		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				ParseResult(ResultInEditor);
				return;
			}


			AndroidDialog popup = AndroidDialog.Create(title, message, yes, no);

			popup.addEventListener(BaseEvent.COMPLETE, OnComplete);
			
		}


		private void OnComplete(CEvent e) {
			
			//romoving listner
			(e.dispatcher as AndroidDialog).removeEventListener(BaseEvent.COMPLETE, OnComplete);
			
			//parsing result
			ParseResult((AndroidDialogResult)e.data);
		}


		private void ParseResult(AndroidDialogResult res) {
			switch(res) {
			case AndroidDialogResult.YES:
				Fsm.Event(yesEvent);
				break;
			case AndroidDialogResult.NO:
				Fsm.Event(noEvent);
				break;
				
			}
			
			Finish();
		}
		
	}
}


