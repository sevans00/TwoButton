﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native")]
	public class PlayServiceShowLeaderboardssUIAction : FsmStateAction {

		public string leaderboardId;


		public override void OnEnter() {
			GooglePlayManager.instance.showLeaderBoardsUI(leaderboardId);
			Finish();
			
		}

	}
}

