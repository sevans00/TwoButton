﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native")]
	public class AndroidNativeDialogPopUpAction : FsmStateAction {
		
		public string title 	= "Like this game?";
		public string message   = "Please rate to support future updates!";

		public string yes 	 = "Okay";
		public string no	 = "No";
		public string later  = "Later";
		public string rateUrl = "LINK_TO_YOUR_APP";

		public FsmEvent yesEvent;
		public FsmEvent noEvent;
		public FsmEvent laterEvent;

		[Tooltip("Result will be fired in unity Editor")]
		public AndroidDialogResult ResultInEditor = AndroidDialogResult.RATED;

		
		
		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				ParseResult(ResultInEditor);
				return;
			}


			AndroidRateUsPopUp rate = AndroidRateUsPopUp.Create(title, message, rateUrl, yes, later, no);

			rate.addEventListener(BaseEvent.COMPLETE, onRatePopUpClose);
			
		}


		private void onRatePopUpClose(CEvent e) {
			
			//romoving listner
			(e.dispatcher as AndroidRateUsPopUp).removeEventListener(BaseEvent.COMPLETE, onRatePopUpClose);
			
			//parsing result
			ParseResult((AndroidDialogResult)e.data);
		}


		private void ParseResult(AndroidDialogResult res) {
			switch(res) {
			case AndroidDialogResult.RATED:
				Fsm.Event(yesEvent);
				break;
			case AndroidDialogResult.REMIND:
				Fsm.Event(laterEvent);
				break;
			case AndroidDialogResult.DECLINED:
				Fsm.Event(noEvent);
				break;
				
			}
			
			Finish();
		}
		
	}
}


